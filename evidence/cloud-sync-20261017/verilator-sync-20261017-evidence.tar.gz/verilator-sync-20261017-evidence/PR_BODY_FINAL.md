Integrate the fixed Veripool master `1d0bf5d1d1766ed98693cfa95dce2c0ae4659ef4` while retaining the four-state fork's guards and history. This brings in 41 official commits beyond PR24, including the five already preserved in the separate C++14 probe. Final candidate: `f663cb23b6d62480ad15fb15448cc85e1d28985a`.

Resolve four conflicts by retaining four-state original dtype/complement metadata, conditional-driver and unknown filename folding guards, conditional inversion safety, warning aliases and implicit delay preparation alongside upstream library-inout, branch prediction, WIDTHDIGITS and clocking tick conversion changes. Preserve PR24 `4493ecd2`, probe `48bb13d6`, both Antmicro tips and the original delivery history. Add the actual CI invocation of the new group and build a real debug compiler for the unchanged interface-array driver.

Preserve the original 264 drivers/27 ordered groups and add 33 unchanged upstream controls, for 297/28 plus the original MT5. The additions cover bounded parameter/array/struct diagnostics, widths, clocking, VPI lifecycle/topology, assertions and grouping. They include ordinary-mode, negative and static controls; their count does not certify arbitrary aggregate X/Z semantics.

[Final-head CI](https://github.com/Mafei/verilator/actions/runs/38985119681) is complete. Independent review read both full decoded logs (12,900,221 bytes), checked actual summaries/exits and re-read complete waveform payloads:

| Validation | macOS ARM64 | Rocky 8.10 x86_64 |
| --- | --- | --- |
| Selected original harness | 297/28, no skip | 297/28, no skip |
| Original MT controls | 5/5 | 5/5 |
| RAM | 318 assertions; 30 histories/228 records | same |
| Strict18 | 16 matches + 2 known differences; full gate exit 1 | same |
| Original finish9 | 9/9; 27 actual wait4 exits 0 | same |
| Relocation/migration | passed | independent fresh Rocky container passed |

All 56 complete cross-platform VCD pairs are byte-for-byte identical. Strict18 has 54 actual compile/build/run Popen exits 0 per platform; this does not remove the two output differences (`nb_ec_concat`, `sv_packed_port1`). No fresh Icarus reference-engine run is claimed. Both platforms built the real debug compiler and passed the unchanged debug-only VPI array test. Enum raw identifiers differ across platforms; normalization preserves type identity and aliases, after which complete AST output matches. Rocky ASAN preflight and fresh-container checks passed; the generated fresh model's maximum observed GLIBC requirement is 2.25.

Internal package SHA-256, recorded consistently before and after migration:

- macOS: `c71a70c4371ee231b0d4b6e8d75fdc0bad5df79df17ad4fbd83a1b37d8ee35ec`
- Rocky: `329b6c65c72b63ab59ff5b7e053e9c22721f52a9af9f1ad2d611a58966b2c079`

Native cloud execution also retained its actual failed attempts: missing Bison PATH, a caught omitted CI group call/Python dependency, opt-only debug-test failure, and MT missing wavediff. Fixes and fresh-object retries are recorded separately; none rewrites an initial failure as a pass. No user Mac was used. Earlier cancelled runs and PR24/probe successes are not inherited as final-head results.

At final observation, official master had advanced two more commits to `8668340f4b7f14af1e0f47f49dd246f27f83a9d7`; both Antmicro tips were unchanged. Those two commits are recorded for the next batch and are not included or certified here. The reusable audit/candidate script does not automatically push or merge back.

Full make test, final complete Cppcheck, solver-positive randomization, 70,000-field stress, special hierarchical/CMake modes, vendor DSP48E2/glbl models and complete SystemVerilog certification remain outside this selected scope. Upstream golden whitespace is preserved. This remains a draft candidate; no release or delivery-branch merge.
