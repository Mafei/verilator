#!/usr/bin/env python3
"""Bind final metadata, whole MT histories and cross-platform enum identities."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import runpy

BASE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--head", required=True)
    p.add_argument("--run-id", type=int, required=True)
    p.add_argument("--macos-log", type=Path, required=True)
    p.add_argument("--rocky8-log", type=Path, required=True)
    args = p.parse_args()
    run = json.loads((BASE / ("run-" + str(args.run_id) + ".terminal.json")).read_text())
    jobs = json.loads((BASE / ("jobs-" + str(args.run_id) + ".terminal.json")).read_text())["jobs"]
    assert run["head_sha"] == args.head and run["status"] == "completed" and run["conclusion"] == "success"
    assert len(jobs) == 2 and {j["name"] for j in jobs} == {"macos", "rocky8"}
    assert all(j["status"] == "completed" and j["conclusion"] == "success" for j in jobs)
    namespace = runpy.run_path(str(BASE / "analyze_complete_logs.py"))
    parse = namespace["parse_vcd"]
    folder = BASE / ("analysis-" + str(args.run_id))
    results, enums = [], {}
    for platform in ("macos", "rocky8"):
        review = json.loads((folder / platform / "PLATFORM_REVIEW.json").read_text())
        assert review["head"] == args.head and review["all_required_log_gates_verified"] is True
        compiler = review["compiler_sha256_records"][0]
        assert all(r["compiler_sha256"] == compiler and args.head[:9] in r["compiler_head"]
                   for r in review["strict18_audits"])
        assert all(r["compiler_physical_sha256"] == compiler
                   for r in review["finish9_audits"])
        log_path = getattr(args, platform + "_log")
        assert sha(log_path) == review["complete_decoded_log_sha256"]
        text = re.sub(r"(?m)^\ufeff?\d{4}-\d\d-\d\dT[^ ]+Z ", "", log_path.read_text())
        debug_commands = [s for s in text.splitlines()
                          if re.match(r"^(?:(?:\S*/)?(?:ccache|sccache)\s+)?(?:\S*/)?(?:clang\+\+|g\+\+|c\+\+)\s", s)
                          and " -DVL_DEBUG" in s and " -D_GLIBCXX_DEBUG" in s and " -c " in s]
        assert debug_commands, "No actual checked-STL debug compiler build commands"
        assert text.count("vlt/t_vpi_interface_ref_array: Self PASSED") == 1
        rejection_lines = [s for s in text.splitlines() if "FOURSTATE_UNKNOWN_REJECTED" in s]
        assert rejection_lines, "Relocated/fresh model's expected unknown-rejection output absent"
        portability = {"platform": platform, "actual_unknown_rejection_output": rejection_lines}
        if platform == "rocky8":
            assert len(re.findall(r"(?m)^ASAN_TOOLSET13_PREFLIGHT_PASSED$", text)) == 1
            assert any(j["name"] == "rocky8" and any(
                s["name"] == "Verify package in a fresh Rocky 8.10 container"
                and s["status"] == "completed" and s["conclusion"] == "success"
                for s in j["steps"]) for j in jobs)
            floors = [part.strip() for line in re.findall(
                r"Required GLIBC versions: ([0-9., ]+)", text) for part in line.split(",")]
            assert floors and all(tuple(map(int, v.split("."))) <= (2, 28) for v in floors)
            portability.update(actual_ASAN_probe_passed=True,
                               actual_separate_fresh_container_step_success=True,
                               actual_fresh_model_GLIBC_versions=floors,
                               actual_fresh_model_max_GLIBC=max(floors, key=lambda v:tuple(map(int,v.split(".")))))
        else:
            versions = re.findall(r"(?m)^GNU Make ([0-9]+(?:\.[0-9]+)+)$", text)
            assert versions and all(tuple(map(int,v.split("."))) >= (4,1) for v in versions)
            portability["actual_GNU_Make_versions"] = versions
        results.append(portability)
        (folder / platform / "REAL_DEBUG_COMPILE_COMMANDS.txt").write_text("\n".join(debug_commands) + "\n")
        results.append({"platform": platform, "actual_debug_compile_command_count": len(debug_commands),
                        "actual_flags": ["-DVL_DEBUG", "-D_GLIBCXX_DEBUG"],
                        "original_vpi_interface_ref_array_driver_actual_pass_records": 1})
        rows = [r for r in review["whole_wave_files"] if r["key"].startswith("THREAD_WAVE_BYTES/")]
        assert len(rows) == 2
        for fourstate, profile in ((False, "two_state"), (True, "four_state")):
            row = next(r for r in rows if "/clocked-MT/" + profile + "/" in r["key"])
            wave = BASE / row["path"]
            assert sha(wave) == row["sha256"] and wave.stat().st_size == row["bytes"]
            time, actual = parse(wave.read_bytes(), {"sample": 33, "phase": 32, "clk": 1})
            zero, one = "0" * 33, "1" * 33
            expected = {
                "sample": [[0, zero], [1, one], [3, "x"*33 if fourstate else zero],
                           *([[5, "z"*33]] if fourstate else []),
                           [7, ("10xz01" if fourstate else "100001").rjust(33, "0")],
                           [9, zero], [11, one]],
                "phase": [[0, "0"*32], *[[2*i-1, format(i, "032b")] for i in range(1, 7)]],
                "clk": [[i, str(i % 2)] for i in range(12)]}
            assert time == 11 and actual == expected
            total = sum(len(v) for v in actual.values())
            assert len(actual) == 3 and total == (26 if fourstate else 25)
            results.append({"platform": platform, "profile": profile, "whole_histories": len(actual),
                            "whole_records": total, "sha256": sha(wave)})
        emap = {}
        for row in review["enum_records"]:
            if row["path"] in emap:
                assert emap[row["path"]] == row
            else:
                emap[row["path"]] = row
        assert emap
        enums[platform] = emap
    assert enums["macos"].keys() == enums["rocky8"].keys()
    enum_pairs = []
    for path in sorted(enums["macos"]):
        mac, rock = enums["macos"][path], enums["rocky8"][path]
        assert mac["normalized_sha256"] == rock["normalized_sha256"]
        enum_pairs.append({"path": path, "raw_sha256_equal": mac["raw_sha256"] == rock["raw_sha256"],
                           "normalized_sha256_equal": True, "macos_raw_sha256": mac["raw_sha256"],
                           "rocky8_raw_sha256": rock["raw_sha256"],
                           "normalized_sha256": mac["normalized_sha256"]})
    result = {"head": args.head, "run_id": args.run_id, "actual_terminal_run_and_jobs_success": True,
              "independent_MT_whole_history_reviews": results, "enum_pairs": enum_pairs,
              "scope": "Whole MT records independently parsed from complete raw VCD bytes. Enum normalization retains suffixes and alias identity; normalized equality is reported separately from raw byte hashes."}
    path = folder / "METADATA_MT_ENUM_REVIEW.json"
    with path.open("x") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
