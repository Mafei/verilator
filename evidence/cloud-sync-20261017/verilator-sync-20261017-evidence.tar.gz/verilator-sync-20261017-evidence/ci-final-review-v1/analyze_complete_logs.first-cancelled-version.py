#!/usr/bin/env python3
"""Read fixed-source complete decoded job logs; never infer results from badges."""
import argparse
import ast
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import types

BASE = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def literal(raw, name):
    for node in ast.parse(raw).body:
        if isinstance(node, ast.Assign) and any(
                isinstance(t, ast.Name) and t.id == name for t in node.targets):
            return ast.literal_eval(node.value)
    raise ValueError(name)


def read_module(path):
    module = {"__file__": str(path), "__name__": "frozen_review_module"}
    exec(compile(path.read_bytes(), str(path), "exec"), module)
    return module


def capture_json(lines, prefix):
    return [json.loads(line[len(prefix):]) for line in lines if line.startswith(prefix)]


def require(condition, message, errors):
    if not condition:
        errors.append(message)


def parse_vcd(raw, wanted):
    """Independently retain all selected VCD records, including repeats."""
    text = raw.decode("ascii")
    assert re.search(r"\$timescale\s+1ps\s+\$end", text)
    assert "$enddefinitions $end" in text and text.endswith("\n")
    scopes, declared, codes = [], {}, {}
    actual = {k: [] for k in wanted}
    timestamp = 0
    for line in text.splitlines():
        parts = line.split()
        if not parts:
            continue
        if parts[0] == "$scope":
            scopes.append(parts[2])
        elif parts[0] == "$upscope":
            scopes.pop()
        elif parts[0] == "$var":
            name = parts[4]
            if name not in wanted:
                continue
            assert int(parts[2]) == wanted[name]
            if name in declared:
                assert declared[name] == parts[3]
            else:
                declared[name] = parts[3]
                codes[parts[3]] = name
        elif line.startswith("#"):
            new_time = int(line[1:])
            assert new_time >= timestamp
            timestamp = new_time
        elif line.startswith("b") and len(parts) == 2 and parts[1] in codes:
            name, value = codes[parts[1]], parts[0][1:].lower()
            assert value and set(value) <= set("01xz") and len(value) <= wanted[name]
            actual[name].append([timestamp, value.rjust(
                wanted[name], value[0] if value[0] in "xz" else "0")])
        elif line[0].lower() in "01xz" and line[1:] in codes:
            name = codes[line[1:]]
            assert wanted[name] == 1
            actual[name].append([timestamp, line[0].lower()])
    assert set(declared) == set(wanted)
    return timestamp, actual


def analyze(platform, log_path, source, head, run_id):
    raw = log_path.read_bytes()
    text = re.sub(r"(?m)^\ufeff?\d{4}-\d\d-\d\dT[^ ]+Z ", "", raw.decode("utf-8"))
    lines = text.splitlines()
    dest = BASE / ("analysis-" + str(run_id)) / platform
    dest.mkdir(parents=True, exist_ok=False)
    errors = []
    result = {"head": head, "run_id": run_id, "platform": platform,
              "complete_decoded_log_bytes": len(raw), "complete_decoded_log_sha256": sha(raw),
              "error_headers": [s for s in lines if s.startswith("##[error]")],
              "gate_observation_limit": "Counts/acceptance audits are re-read from actual job log; artifact ZIP and 54 strict individual raw logs were not downloaded."}
    require(head in text, "Exact final SHA absent from complete log", errors)
    require(not result["error_headers"], "Actual Actions error header present", errors)
    groups = literal((source / "ci/portable/run_regressions.py").read_bytes(), "GROUPS")
    shell = (source / "ci/portable/build.bash").read_text()
    command = next(s for s in shell.splitlines() if s.startswith("python3 ci/portable/run_regressions.py "))
    order = command.split(" || ", 1)[0].split()[2:]
    require(set(order) == set(groups) and len(order) == len(groups), "Shell omits or duplicates a group", errors)
    summaries = list(re.finditer(r"(?m)^==TESTS DONE, ([^\n]+)$", text))
    result["completed_harness_summaries"] = len(summaries)
    group_rows, start = [], 0
    for index, name in enumerate(order):
        if index >= len(summaries):
            group_rows.append({"group": name, "status": "NOT_REACHED"})
            continue
        summary = summaries[index]
        segment = text[start:summary.start()]
        status, _, tail = summary.group(1).partition(": ")
        counts = {k.lower(): int(v) for k, v in re.findall(
            r"\b(Passed|Failed(?:-First)?|Skipped|Left|Running) (\d+)\b", tail)}
        actual = re.findall(r"(?m)^vlt/(t_[A-Za-z0-9_]+): Self PASSED$", segment)
        passed = (status == "PASSED" and counts.get("passed") == len(groups[name])
                  and counts.get("failed") == 0
                  and all(counts.get(k, 0) == 0 for k in ("skipped", "failed-first", "left", "running"))
                  and len(actual) == len(set(actual)) == len(groups[name])
                  and set(actual) == {"t_" + n for n in groups[name]})
        group_rows.append({"group": name, "summary": summary.group(1), "counts": counts,
                           "actual_pass_names": actual, "actual_selection_passed": passed})
        require(passed, "Failed/incomplete/mismatched original driver group: " + name, errors)
        start = summary.end()
    require(len(summaries) == len(order) + 1, "Expected main groups plus one MT summary", errors)
    result["groups"] = group_rows
    result["expected_main_driver_count"] = sum(map(len, groups.values()))
    result["main_group_count"] = len(groups)
    result["actual_main_pass_count"] = sum(len(x.get("actual_pass_names", [])) for x in group_rows)
    result["gate_unit_test_counts"] = [int(s) for s in re.findall(r"(?m)^Ran (\d+) tests? in ", text)]
    require(13 in result["gate_unit_test_counts"], "Original13 gate unit tests not observed", errors)
    result["independent_results_checks"] = text.count("Verified regression counts for " + head)
    require(result["independent_results_checks"] == 2, "Missing build and independent main-results checks", errors)
    thread = capture_json(lines, "THREAD_CONTROLS ")
    result["thread_controls"] = thread
    expected_mt = literal((source / "ci/portable/run_thread_controls.py").read_bytes(), "NAMES")
    require(len(thread) == 1 and thread[0].get("commit") == head
            and thread[0].get("success") is True and thread[0].get("returncode") == 0
            and thread[0].get("selected") == list(expected_mt)
            and len(thread[0].get("actual_pass_names", [])) == 5
            and set(thread[0].get("actual_pass_names", [])) == {"t_" + n for n in expected_mt},
            "MT5 missing/failed/changed", errors)
    raw_json = []
    for line in lines:
        if line.startswith("{") and line.endswith("}"):
            try:
                raw_json.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    strict = [x for x in raw_json if x.get("selected") == 18 and "native_counts" in x]
    result["strict18_audits"] = strict
    require(len(strict) == 3 and all(x == strict[0] for x in strict), "Strict18 run/check/full18 audit mismatch", errors)
    for row in strict:
        require(row.get("compiler_head") == head and row.get("applicable_counts") == {"passed": 16}
                and row.get("strict_gate_exit") == 0 and row.get("skipped_selected") == 0
                and row.get("unrun_selected") == 0 and row.get("actual_receipts_logs_and_protection_verified") is True
                and row.get("diagnostic_infrastructure_failures") == []
                and row.get("native_counts") == {"compile_exit_0": 18, "build_exit_0": 18, "run_exit_0": 18, "timed_out": 0},
                "Strict18 actual subprocess/16-case acceptance/provenance failure", errors)
    result["strict18_full18_exit_is_not_suppressed_in_report"] = [x.get("full18_gate_exit") for x in strict]
    waves, wave_rows = {}, []
    prefixes = {"SEMANTIC_WAVE_BYTES ": 7, "FINISH_WAVE_BYTES ": 20,
                "CONTROLS_WAVE_BYTES ": 17, "THREAD_WAVE_BYTES ": 2, "RAM_WAVE_BYTES ": 1}
    for prefix, count in prefixes.items():
        payload = capture_json(lines, prefix)
        require(len(payload) == 1, "Missing/duplicate complete wave payload: " + prefix, errors)
        if len(payload) != 1:
            continue
        rows = payload[0].get("records", [])
        require(len(rows) == count, "Unexpected wave count: " + prefix, errors)
        total = 0
        for index, row in enumerate(rows):
            content = row["contents_utf8"].encode("utf-8")
            require(len(content) == row["bytes"] and sha(content) == row["sha256"], "Wave length/hash mismatch", errors)
            require(content.endswith(b"\n") and b"$enddefinitions $end" in content
                    and re.search(rb"(?m)^#[0-9]+", content), "Incomplete whole wave", errors)
            key = prefix.split()[0] + "/" + row["fixture"] + "/" + Path(row["path"]).name
            require(key not in waves, "Duplicate whole wave identity", errors)
            path = dest / "whole-waves" / (prefix.split()[0] + "-" + str(index) + ".vcd")
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
            waves[key] = content
            wave_rows.append({"key": key, "path": str(path.relative_to(BASE)), "bytes": len(content), "sha256": sha(content)})
            total += len(content)
        require(total == payload[0]["total_bytes"] and total <= payload[0]["budget_bytes"], "Wave collection budget/total mismatch", errors)
    ram = [x for x in raw_json if x.get("status") == "PASS_LITERAL_OUTPUT_AND_COMPLETE_HISTORIES"]
    result["ram_acceptance"] = ram
    require(len(ram) == 1 and all(ram[0].get(k) == v for k, v in {
        "assertions_total": 318, "phase_reports": 84, "complete_signal_histories": 30,
        "complete_history_records": 228, "label": head}.items()), "RAM counts/identity missing or incomplete", errors)
    ram_paths = [BASE / row["path"] for row in wave_rows if row["key"].startswith("RAM_WAVE_BYTES/")]
    if len(ram_paths) == 1:
        module = read_module(source / "ci/portable/ram-matrix-original/verify_matrix.py")
        actual = module["parse_vcd"](ram_paths[0], module["expected_histories"]())
        result["independent_RAM_whole_histories"] = len(actual)
        result["independent_RAM_whole_records"] = sum(map(len, actual.values()))
        require(len(actual) == 30 and sum(map(len, actual.values())) == 228, "Independent RAM whole-history mismatch", errors)
    finish = capture_json(lines, "FINISH9_CASE ")
    audits = capture_json(lines, "FINISH9_AUDIT ")
    result["finish9_audits"] = audits
    fm = read_module(source / "ci/portable/finish_acceptance.py")
    originals = source / "ci/portable/finish9-original"
    require({name: sha((originals / name).read_bytes()) for name in fm["ORIGINAL_SHA256"]} == fm["ORIGINAL_SHA256"], "Original finish inputs/oracle bytes changed", errors)
    control, _ = fm["original_functions"](originals / "run_controls_v2.py", ["expected", "check", "wave"])
    noninline, _ = fm["original_functions"](originals / "run_noninline_v2.py", ["check"])
    pids, check_results = [], []
    require(len(finish) == 9 and [x.get("case") for x in finish] == [0, 1, 2, 3, 4, 5, 6, 7, 9]
            and [x.get("id") for x in finish] == fm["PROFILES"], "Finish9 profiles missing/reordered", errors)
    for row in finish:
        folder = dest / "original-finish9" / str(row["case"])
        folder.mkdir(parents=True, exist_ok=True)
        log = folder / "run.log"
        log.write_bytes(row["full_raw_output_utf8"].encode("utf-8"))
        wave = folder / "wave.vcd"
        wave.write_bytes(row["wave_complete_utf8"].encode("utf-8"))
        checked = control["check"](log, row["case"]) if row["case"] != 9 else noninline["check"]({"log": str(log), "native_exit": row["stages"]["run"]["actual_exit"]})
        checked_wave = control["wave"](wave)
        require(checked == row["check"] and all(v == row["wave"].get(k) for k, v in checked_wave.items() if k != "path")
                and len(wave.read_bytes()) == row["wave_bytes"] and row.get("strict_passed") is True,
                "Original finish literal output/full-wave oracle mismatch", errors)
        for phase in ("compile", "build", "run"):
            stage = row["stages"][phase]
            require(type(stage["pid"]) is int and stage["pid"] == stage["wait4_pid"]
                    and type(stage["raw_wait_status"]) is int and stage["raw_wait_status"] == 0
                    and type(stage["actual_exit"]) is int and stage["actual_exit"] == 0
                    and stage["termination_reason"] is None, "Finish native wait4 record not actual success", errors)
            pids.append(stage["pid"])
        require(row["stages"]["run"]["log_sha256"] == sha(log.read_bytes()), "Finish raw runtime log SHA mismatch", errors)
        key = "ORIGINAL_FINISH9/" + row["id"]
        waves[key] = wave.read_bytes()
        wave_rows.append({"key": key, "path": str(wave.relative_to(BASE)), "bytes": len(wave.read_bytes()), "sha256": sha(wave.read_bytes())})
        check_results.append({"case": row["case"], "id": row["id"], "literal_output_and_wave_rechecked": checked, "q_history": checked_wave["q_raw_selected_history"]})
    require(len(pids) == len(set(pids)) == 27, "Finish9 does not have27 distinct actual wait4 records", errors)
    require(len(audits) == 1 and audits[0].get("commit") == head and audits[0].get("passed") == 9
            and audits[0].get("failed") == 0 and audits[0].get("NOTRUN") == []
            and audits[0].get("strict_gate_exit") == 0 and audits[0].get("original_files_unchanged") is True,
            "Finish9 final audit missing/incomplete", errors)
    result["finish9_independent_literal_checks"] = check_results
    result["finish9_distinct_actual_wait4_pid_count"] = len(set(pids))
    result["whole_wave_count"] = len(waves)
    require(len(waves) == 56, "All56 complete wave payloads were not reached", errors)
    result["whole_wave_files"] = wave_rows
    result["compiler_sha256_records"] = re.findall(r"(?m)^COMPILER_SHA256 ([0-9a-f]{64})  bin/verilator_bin$", text)
    result["package_sha256_records"] = re.findall(r"(?m)^([0-9a-f]{64})  (verilator-fourstate-[^ \n]+\.tar\.gz)$", text)
    require(len(result["compiler_sha256_records"]) == 1 and len(result["package_sha256_records"]) == 2
            and len(set(tuple(x) for x in result["package_sha256_records"])) == 1, "Missing or unstable compiler/package SHA", errors)
    result["enum_records"] = capture_json(lines, "DEBUG_ENUM_EVIDENCE ")
    result["original_acceptance_exit_lines"] = [s for s in lines if s.startswith("ORIGINAL_ACCEPTANCE_EXITS ")]
    result["thread_ram_exit_lines"] = [s for s in lines if s.startswith("SYNC_20261013_CONTROL_EXITS ")]
    result["ASAN_preflight_count"] = text.count("ASAN_TOOLSET13_PREFLIGHT_PASSED")
    result["GLIBC_observed_versions"] = sorted(set(re.findall(r"GLIBC_(\d+\.\d+)", text)), key=lambda s:tuple(map(int,s.split("."))))
    result["errors"] = errors
    result["all_required_log_gates_verified"] = not errors
    (dest / "PLATFORM_REVIEW.json").write_text(json.dumps(result, indent=2) + "\n")
    return result, waves


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--head", required=True)
    p.add_argument("--run-id", type=int, required=True)
    p.add_argument("--macos", type=Path, required=True)
    p.add_argument("--rocky8", type=Path, required=True)
    args = p.parse_args()
    source = BASE / ("source-" + args.head[:8])
    m = json.loads((source / "SOURCE_MANIFEST.json").read_text())
    assert m["head"] == args.head
    for f in m["files"]:
        raw = (source / f["path"]).read_bytes()
        assert len(raw) == f["bytes"] and sha(raw) == f["sha256"]
    assert sum(p.stat().st_size for p in BASE.glob("*.log")) <= 24*1024*1024
    mac, mw = analyze("macos", args.macos, source, args.head, args.run_id)
    rock, rw = analyze("rocky8", args.rocky8, source, args.head, args.run_id)
    pairs = [{"key":k, "macos_bytes":len(mw[k]), "rocky8_bytes":len(rw[k]),
              "macos_sha256":sha(mw[k]), "rocky8_sha256":sha(rw[k]),
              "complete_bytes_equal":mw[k] == rw[k]} for k in sorted(set(mw) & set(rw))]
    both = (mac["all_required_log_gates_verified"] and rock["all_required_log_gates_verified"]
            and set(mw) == set(rw) and len(pairs) == 56 and all(x["complete_bytes_equal"] for x in pairs))
    result = {"head":args.head,"run_id":args.run_id,"whole_wave_pair_count":len(pairs),
              "pairs":pairs,"both_complete_platform_log_reviews_passed":both,
              "macos_errors":mac["errors"],"rocky8_errors":rock["errors"],
              "scope":"Actual final job metadata must also be terminal success. No ZIP bytes downloaded; no fullSV/vendor/fullmake/Cppcheck/SMT/70K certification."}
    (BASE / ("analysis-"+str(args.run_id)) / "CROSS_PLATFORM_REVIEW.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({k:v for k,v in result.items() if k != "pairs"},indent=2))
    raise SystemExit(0 if both else 1)


if __name__ == "__main__":
    main()
