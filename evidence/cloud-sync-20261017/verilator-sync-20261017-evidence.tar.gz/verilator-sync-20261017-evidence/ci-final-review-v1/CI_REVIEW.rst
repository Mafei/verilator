Final independent portable CI review, 2026-10-17
================================================

Final source: f663cb23b6d62480ad15fb15448cc85e1d28985a
Tree: d82b68edc00f9d29ebd9ba7af8755d72319a5deb
Draft PR25: https://github.com/Mafei/verilator/pull/25
Final run: https://github.com/Mafei/verilator/actions/runs/38985119681
Actual run and both jobs: completed / success, final update 2026-10-17T01:12:01Z.
PR25 remains draft/open/unmerged, based on certified PR24 4493ecd2.

The selected suite actually completed 297 unique drivers in 28 groups on each
platform, with 0 failures and 0 skips. The original 264 drivers/27 ordered group
lists are byte-for-byte preserved; 33 controls are additive. 29 completed harness
summaries per platform include the independent MT5 selection. Exact actual pass
names, counts, completed summaries and two independent recorded-result/provenance
checks were verified from the complete logs. The original 13 regression failure-
propagation unit cases completed; all observed fixture-suite counts are
13, 13, 11, 7, 16 on each platform. This is not a claim of297 runtime simulations.

Both platforms actually built the debug compiler:176 compile commands each carry
-DVL_DEBUG and-D_GLIBCXX_DEBUG. The original vpi_interface_ref_array driver,
including its --debug invocation, has exactly one actual pass record. Its driver
and the acceptance criteria were not weakened. macOS used GNU Make 4.4.1.

RAM: 318 assertions, 84 phase reports, 30 complete selected histories and 228 raw
records. Its complete VCD was independently parsed again using the unchanged
literal whole-history oracle. MT5 passed; the two clocked MT waves were also
independently parsed, retaining every record: 3 histories with 25 two-state and
26 four-state records.

Strict18: all 18 inputs execute. 16 match and 2 retain their original output
differences (nb_ec_concat, sv_packed_port1). The full18 check actually exits 1;
it is not reported as all passed. Each platform's three identical actual
run/check/full18 audits verify 54 Popen stage exits 0, no timeout, no skip/unrun,
29 original source/gold/license inputs and protected compiler/runtime identity.
These 54 individual raw stage log files were not downloaded locally; the frozen
CI runner re-read their actual receipts and complete unfiltered logs before
printing the audited counts. No Icarus reference compiler was run by this CI.

Finish9: 9/9 original literal stdout criteria pass, with 27 distinct actual wait4
PID records/raw statuses 0 per platform. Full stdout and all 9 complete waves were
recovered and rechecked against the unchanged original oracle functions. Case 5's
q=0 remains its original bounded acceptance criterion, not an IEEE certification.

Every complete VCD payload was recovered and length/SHA checked:7 semantic,
20 finish-boundary, 17 SV controls, 2 MT, 1 RAM and 9 original finish controls.
All 56 cross-platform pairs are byte-for-byte identical with equal SHA256.
The debug enum tree has different raw host hashes, while normalization of only
the 8-hex enum type identities (preserving suffixes/aliases) yields equal hashes.
Raw equality and normalized equality are deliberately reported separately.

Rocky actually ran its toolset 13 ASAN probe and a separate fresh Rocky 8.10
container migration step. The installed package compiled and ran both ordinary
and expected unknown-rejection smoke models. The fresh model's observed maximum
GLIBC requirement is 2.25; this is below 2.28. macOS relocated smoke also ran its
expected unknown rejection. Expected rejected-model fatal output is not an
unexpected job failure. CI's compiler dependency checker also passed.

The primary deep-review process PID 69538 ended raw wait 0/actual exit0. Its
independent metadata/debug/MT/portability review PID 69546 also ended raw 0/exit0.
Both actual observer receipts and complete review logs are included.

Package and artifact identities
-------------------------------

macos-arm64
  Internal tar: verilator-fourstate-macos-arm64.tar.gz
  SHA256: c71a70c4371ee231b0d4b6e8d75fdc0bad5df79df17ad4fbd83a1b37d8ee35ec
  Compiler SHA256: 6a6c2c1aee17ad83d7580f4d001c43a15173fa868a9d70862df7be0a3c9bd31e
  Artifact ID: 12085030039
  ZIP bytes(metadata): 497519729
  ZIP digest(metadata): sha256:8827a434058ba2b7934404b47f67abcb1b8316b5c387810dd20032a52f6121f4
  Download: https://github.com/Mafei/verilator/actions/runs/38985119681/artifacts/12085030039

rocky8-x86_64
  Internal tar: verilator-fourstate-rocky8-x86_64.tar.gz
  SHA256: 329b6c65c72b63ab59ff5b7e053e9c22721f52a9af9f1ad2d611a58966b2c079
  Compiler SHA256: 607b36e1ae2b379e2a0b2988775b7704b75ae700a302a46effb08677516de208
  Artifact ID: 12083889322
  ZIP bytes(metadata): 452541681
  ZIP digest(metadata): sha256:f094df87a2c8f48b29c7c05eb23edfcf379c81f21bd97751b6b16e328f54f68a
  Download: https://github.com/Mafei/verilator/actions/runs/38985119681/artifacts/12083889322

The internal tar SHA above is printed twice in the actual CI output manifests.
Artifact ZIP sizes/digests are different objects, obtained from GitHub metadata.
The large 452-497MB ZIPs were not downloaded. Internal tar byte size is unknown
from these logs and is not substituted with ZIP size. Compiler physical hashes
match the independent strict18 and finish9 identity audits.

Complete decoded logs
---------------------

macOS:7,064,102 bytes, SHA256
15f16887b26fafbc9e2dfb276c796de5d554db9aa805f81708e35355c6c61a06
Rocky:5,836,119 bytes, SHA256
266f41ff6aeda659573e3aff24c333e46d8a4024a292bfbb2ba9bc1a990c0dff
All final and two earlier cancelled-run complete logs total 13,846,526 bytes,
within the 24 MiB review budget. They are full decoded GitHub job text, not excerpts.

Historical failures and scope
-----------------------------

627420e2/run 38984388388 omitted the additive 28th group from build.bash. The
parent's native unit run observed 1 failure + 2 missing-distro errors (11 actual
methods because the enum class setup failed). Formal CI was cancelled before
units/main/post gates and did not observe this native failure.

a32b59d2/run 38984569961 fixed the group invocation. The parent's native new 33
controls observed 32 passes + 1 missing-real-debug failure. Formal CI was cancelled
before units/main/post gates; it did not itself observe that native failure.
Both earlier complete cancelled-job logs and separate source snapshots are
retained. No final pass is inherited from them, PR24, the three-control Linux
probe, or the local native run. f663 adds the real debug compiler build; the
final two platforms execute all mandatory gates afresh, with none NOT_REACHED.

No full make-test, full Cppcheck, positive SMT, 70K constructor, restricted vendor
model, or complete SystemVerilog certification is claimed. The fixed upstream
snapshot in f663 is 1d0bf5d1d1766ed98693cfa95dce2c0ae4659ef4; later upstream
commits belong to the parent's next-batch record. The reviewer did not build,
dispatch/cancel CI, edit source/Git refs, merge delivery PRs, or use a local Mac.
