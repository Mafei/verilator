#!/usr/bin/env python3
"""Close this agent-owned evidence directory after all actual reviews finish."""
import datetime
import hashlib
import json
from pathlib import Path

base = Path(__file__).resolve().parent
assert not (base / "MANIFEST.json").exists() and not (base / "SEALED.json").exists()
result = json.loads((base / "SCOPED_FINAL_RESULT.json").read_text())
assert result["head"] == "f663cb23b6d62480ad15fb15448cc85e1d28985a"
assert result["run_id"] == 38985119681 and result["run_conclusion"] == "success"
assert result["all56_cross_platform_byte_and_SHA_pairs_equal"] is True
assert result["final_mandatory_unreached_gates"] == []
assert sum(p.stat().st_size for p in base.glob("*.log")) <= 24*1024*1024
files = []
for path in sorted(base.rglob("*")):
    assert not path.is_symlink(), str(path)
    if path.is_file():
        raw = path.read_bytes()
        files.append({"path": str(path.relative_to(base)), "bytes": len(raw),
                      "sha256": hashlib.sha256(raw).hexdigest()})
manifest = {"head": result["head"], "run_id": result["run_id"],
            "scope": "Both final platforms and all56 complete wave pairs independently verified; known strict18 two differences/full18 exit1 retained.",
            "files": files}
(base / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
for row in files:
    raw = (base / row["path"]).read_bytes()
    assert len(raw) == row["bytes"] and hashlib.sha256(raw).hexdigest() == row["sha256"]
seal = {"sealed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "head": result["head"], "tree": result["tree"], "run_id": result["run_id"],
        "files": len(files), "total_bytes": sum(row["bytes"] for row in files),
        "MANIFEST_SHA256": hashlib.sha256((base / "MANIFEST.json").read_bytes()).hexdigest(),
        "CI_REVIEW_SHA256": hashlib.sha256((base / "CI_REVIEW.rst").read_bytes()).hexdigest(),
        "SCOPED_FINAL_RESULT_SHA256": hashlib.sha256((base / "SCOPED_FINAL_RESULT.json").read_bytes()).hexdigest(),
        "all_manifest_file_bytes_reread_and_verified": True,
        "no_further_agent_writes": True}
(base / "SEALED.json").write_text(json.dumps(seal, indent=2) + "\n")
print(json.dumps(seal, indent=2))
