#!/usr/bin/env python3
# DESCRIPTION: Verilator: Verilog Test driver/expect definition
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of either the GNU Lesser General Public License Version 3
# or the Perl Artistic License Version 2.0.
# SPDX-FileCopyrightText: 2026 Wilson Snyder
# SPDX-License-Identifier: LGPL-3.0-only OR Artistic-2.0

import vltest_bootstrap

test.scenarios('simulator')
test.top_filename = 't/t_timing_monitor_postponed.v'
test.compile(
    verilator_flags2=[
        '--binary',
        '--fourstate',
        '--stats',
        '--sched-zero-delay',
        '-Wno-FUTURE',
    ],
    v_flags2=['+define+MONITOR_XZ'],
)
test.execute(
    expect_filename=test.golden_filename,
    iv_run_expect_filename=test.golden_filename,
    iv_run_flags=['-N'],
)
test.file_grep(test.run_log_filename, r'Monitor checks: (\d+)', 19)
if test.vlt_all:
    test.file_grep(test.stats, r'Assertions, postponed monitors\s+(\d+)', 5)
test.passes()
