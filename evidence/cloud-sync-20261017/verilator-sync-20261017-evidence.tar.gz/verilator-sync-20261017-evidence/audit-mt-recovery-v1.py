#!/usr/bin/env python3
"""Apply the unchanged original MT5 summary/name predicate to a fresh harness run."""
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path('/workspace/candidates/sync-20261017/source')
OUT = Path('/workspace/evidence/daily-sync-20261017/native-mt-recovery-v1')
sys.path.insert(0, str(ROOT / 'ci/portable'))
from run_thread_controls import NAMES
from run_regressions import parse_summary, passed_counts

receipt = json.loads((OUT / 'MT5.finished.json').read_text())
log = (OUT / 'MT5.log').read_text()
status, counts = parse_summary(log)
actual = re.findall(r'^vltmt/(t_[A-Za-z0-9_]+): Self PASSED$', log, re.MULTILINE)
expected = {'t_' + name for name in NAMES}
result = {
    'commit': 'f663cb23b6d62480ad15fb15448cc85e1d28985a',
    'selected': list(NAMES), 'object_suffix': '_toolsfix',
    'summary_status': status, 'counts': counts, 'actual_pass_names': actual,
    'original_failure_is_preserved': True,
    'unchanged_parser_module_sha256': hashlib.sha256((ROOT / 'ci/portable/run_thread_controls.py').read_bytes()).hexdigest(),
    'receipt': receipt,
}
result['success'] = (receipt['actual_exit'] == 0 and receipt['raw_wait_status'] == 0
                     and passed_counts(status, counts, len(NAMES))
                     and len(actual) == len(set(actual)) == len(NAMES) and set(actual) == expected)
(OUT / 'results.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'success': result['success'], 'counts': counts, 'summary_status': status}))
sys.exit(0 if result['success'] else 1)
