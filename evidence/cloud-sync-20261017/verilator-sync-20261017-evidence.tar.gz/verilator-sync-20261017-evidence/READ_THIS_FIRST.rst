2026-10-17 云端固定候选证据导航
==============================

本快照属于公开 Mafei/verilator 候选
f663cb23b6d62480ad15fb15448cc85e1d28985a，tree
d82b68edc00f9d29ebd9ba7af8755d72319a5deb，draft PR25。
最终报告单独交付；本目录的 REPORT_DRAFT.rst、CANDIDATE.json、FIXED_SNAPSHOT.json
和各 progress/initial 文件保留其记录时的身份，不能覆盖后续终态或视为统一一次通过。

* source-review-v1：a32 固定静态三方合并、531 路径与诊断枚举检查。
* source-review-followup-v1：a32 到 f663 的仅 CI 四行真实 dbg 构建改动。
* ci-review-v1：首版 CI 静态预检，不是最终运行认证。
* ci-final-review-v1：最终 run38985119681 的完整解码日志、固定源文件、逐门解析、
  包哈希及完整跨平台波形审查；也保留此前两个被并发规则取消的完整日志。
* native-review-v1：旧 opt627 上的 65 个不同原 driver，及真实 f663 dbg 上恢复的
  原 VPI array1项，共66个不同driver；原新增组首轮仍是32过1失败。
* native-semantic-review-v1：最终 opt 元数据更新后的原 RAM、strict18、finish9、
  VPI C++14、MT5 及完整波形的独立审查。strict18 两差异及首轮 MT 失败分开保留。
* native-semantic-bundle-v1：RAM/strict/finish 按原门执行；MT 首轮缺 wavediff 使
  bundle STOPPED_FAILED，外层退出1。这个事实没有因后续补测变为通过。
* native-mt-initial-failed-v1：原 out/thread-controls 全部冻结副本。
* native-mt-recovery-v1：真实 wavetools0.1.2 后、唯一 _toolsfix 对象目录的原 MT5
  重跑与 wait4 收据。5项的实际线程配置遵循原驱动；basic VCD 用3线程，其余用2线程。
* native-tools-provenance-v1 / native-wavetools-install-v1：公开 crate、原锁文件、
  固定 Rust1.88.0/wavetools0.1.2 的真实安装命令、HTTPS日志、退出及工具全文件哈希。
* native-runtime-v1 / native-runtime-final-v1：旧627与最终版本元数据f663的原生
  ELF，仅属 Debian13.6/glibc2.41，不是 macOS/Rocky 移植交付包。
* failure-gate-tests-v1/v2、native-build-v1/v2、native-new-controls-v1：初次真实
  失败和后续修正分列；原失败退出、完整输出、计数和状态不会被后续成功抹去。
* merge-inputs-v1：全部四个冲突的原始三方全文和未解决片段。
* ROOT_SEALED_REVIEW_VERIFICATION*.json：root 对独立审查各清单的每文件重读检查。

SEALED_MANIFEST.json 对归档中每个原始文件记录完整大小和 SHA-256；封存工具重新
打开归档并逐成员全字节核对。归档本身的哈希在单独最终报告中，避免自引用。
所有测试均为选定范围；未认证完整 SystemVerilog、厂商模型或未执行的完整测试。
